# P2 manuscript v4.2 source (commit 68e6d1a)
Anonymous review source. Official ICML 2026 style kit files (icml2026.sty, icml2026.bst,
algorithm.sty, algorithmic.sty, fancyhdr.sty) are included UNMODIFIED from
https://media.icml.cc/Conferences/ICML2026/Styles/icml2026.zip
(sha256 8b29290f5828e176debb57ea9cc00252502973d55ea561a2f18a7f0a326bfc6c); their headers and
notices are retained. TARGET_YEAR=2027, TEMPLATE_YEAR=2026 (provisional), SUBMISSION_READY=false.
Build (as executed for the delivered PDF, TeX Live 2026 scheme-basic + pgf pgfplots cleveref
mathtools microtype booktabs xcolor natbib url fancyhdr algorithms latexmk psnfss times
collection-fontsrecommended etoolbox caption float eso-pic forloop):
  latexmk -pdf -interaction=nonstopmode -halt-on-error -no-shell-escape main.tex
Tables under generated/ are stored outputs of scripts/make_paper_tables.py (results/raw);
no experiment is needed to build. PDF sha256 2223a741ed410c18b62b7a6ce99894567cdd21fbf24248065ab4797ef8517e54.
