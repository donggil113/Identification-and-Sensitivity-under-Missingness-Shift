Anonymous source + PDF (v4.1). Official ICML 2026 kit files included unmodified.
Build: latexmk -pdf -interaction=nonstopmode main.tex (TeX Live with pgfplots, cleveref, mathtools, microtype, booktabs, natbib, eso-pic, forloop, psnfss/times, fontsrecommended).
