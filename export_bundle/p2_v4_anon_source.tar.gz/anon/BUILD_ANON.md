Anonymous source. Put the official ICML 2026 kit (icml2026.sty, icml2026.bst) here, then: latexmk -pdf -interaction=nonstopmode main.tex
COMPILE_NOT_RUN in the authoring environment.
