Anonymous source + PDF (v4.2). Official ICML 2026 kit files included unmodified (source: https://media.icml.cc/Conferences/ICML2026/Styles/icml2026.zip, sha256 8b29290f5828e176debb57ea9cc00252502973d55ea561a2f18a7f0a326bfc6c).
Build: latexmk -pdf -interaction=nonstopmode main.tex
